package com.mygdx.game;

public class TankOne extends Tank{
    public TankOne(int tankNum) {
        super(tankNum);
        setTankAngle(0);
    }
}

package com.mygdx.game;

public class TankThree extends Tank{
    public TankThree(int tankNum) {
        super(tankNum);
    }
}

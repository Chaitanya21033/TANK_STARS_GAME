package com.mygdx.game;

public class TankFour extends Tank {
    public TankFour(int tankNum) {
        super(tankNum);
    }
}

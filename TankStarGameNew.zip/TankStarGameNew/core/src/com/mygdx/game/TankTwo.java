package com.mygdx.game;

public class TankTwo extends Tank{
    public TankTwo(int tankNum) {
        super(tankNum);
    }
}

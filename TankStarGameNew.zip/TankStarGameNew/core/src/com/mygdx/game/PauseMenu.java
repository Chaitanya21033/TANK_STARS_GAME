package com.mygdx.game;

import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import static com.badlogic.gdx.Gdx.input;

public class PauseMenu extends ScreenAdapter {
    private BattleArena battleArena;
    private Main mainClass;
    Stage stage;
    private SpriteBatch batch;
    private Sprite mainImage;
    private OrthographicCamera camera;
    private ImageButton resumeB, exitB, saveB;
    public PauseMenu(final Main mainClass, final BattleArena battleArena,int screen) {
        this.mainClass = mainClass;
        this.battleArena = battleArena;
        stage = new Stage(new ScreenViewport());
        camera = new OrthographicCamera(1920,1080);
        batch = new SpriteBatch();
        mainImage = new Sprite(new Texture(String.format("screens/pause%d.jpg",screen)));
        mainImage.setPosition(-960,-540);
        resumeB    = Button.getButton("playB");
        exitB    = Button.getButton("exitB");
        saveB= Button.getButton("retrieveB");
        resumeB.setPosition(600,200);
        exitB.setPosition(780,60);
        saveB.setPosition(420,60);
        resumeB.setHeight(180);
        exitB.setHeight(180);
        saveB.setHeight(180);
        resumeB.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                mainClass.setScreen(battleArena);
                return true;
            }
        });
        exitB.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                mainClass.setScreen(StartingPage.getInstance());
                return true;
            }
        });
        saveB.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
//                mainClass.setScreen(SaveMenu.getInstance(mainClass, battleArena));
                return true;
            }
        });
        stage.addActor(resumeB);
        stage.addActor(exitB);
        stage.addActor(saveB);
        input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0.2f, 1);
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        mainImage.draw(batch);
        batch.end();
        stage.act();
        stage.draw();
    }

}



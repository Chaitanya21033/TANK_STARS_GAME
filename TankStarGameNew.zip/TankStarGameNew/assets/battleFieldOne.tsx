<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="battleField1" tilewidth="32" tileheight="32" tilecount="1980" columns="60">
 <image source="screens/battleField1.jpg" width="1920" height="1080"/>
</tileset>
